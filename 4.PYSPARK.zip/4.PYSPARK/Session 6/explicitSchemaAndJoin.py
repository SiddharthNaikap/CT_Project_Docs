import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as fn
from pyspark.sql.types import StructType,StructField,StringType,DateType,IntegerType

spark = SparkSession\
        .builder\
        .appName("schemaAndJoin")\
        .master("local[2]")\
        .getOrCreate()

custInvSchema = StructType([
    StructField("invno",IntegerType()),
    StructField("invdate",DateType()),
    StructField("invamt",IntegerType()),
    StructField("custid",StringType()),
    StructField("city",StringType())
])

custSchema = StructType([
    StructField("custid",StringType()),
    StructField("custname",StringType()),
    StructField("creditbal",IntegerType())
])

custInvoices = spark.read\
            .format("csv")\
            .option("header","true")\
            .schema(custInvSchema)\
            .option("dateFormat","dd/MM/yyyy")\
            .load(sys.argv[1])
            # .load("./custOrder1.txt")

customers = spark.read\
            .format("csv")\
            .option("header","true")\
            .schema(custSchema)\
            .load(sys.argv[2])
            # .load("./custOrder1.txt")

custInvoicesNew= custInvoices.withColumn("InvPaymentBy",fn.col("invdate")+15)\
                            .withColumn("discount",fn.col("invamt")*0.1)\
                            .withColumn("invbucket",fn.expr("case when invamt >=5000 then 'Higher' else 'Lower' end"))

custInvoiceJoin = custInvoicesNew.join(customers,customers.custid==custInvoicesNew.custid,"inner").drop(customers.custid)

custInvoiceJoin.show()

custInvoiceJoin.write\
    .format("json")\
    .mode("append")\
    .partitionBy("city")\
    .option("path","invoicesByCity")\
    .save()

custInvoiceJoin.write\
    .format("json")\
    .mode("append")\
    .partitionBy("custid")\
    .option("path","invoicesByCustId")\
    .save()
    
# +-----+----------+------+------+------+------------+--------+---------+--------+---------+
# |invno|   invdate|invamt|custid|  city|InvPaymentBy|discount|invbucket|custname|creditbal|
# +-----+----------+------+------+------+------------+--------+---------+--------+---------+
# |    1|2019-10-01|  7000|  c101|mumbai|  2019-10-16|   700.0|   Higher|   Anand|    18000|
# |    2|2019-07-01|  3600|  c101|mumbai|  2019-07-16|   360.0|    Lower|   Anand|    18000|
# |    3|2019-11-01|  6900|  c102|  pune|  2019-11-16|   690.0|   Higher|  Milind|    23990|
# |    1|2019-10-01|  7000|  c101|mumbai|  2019-10-16|   700.0|   Higher|   Anand|    18000|
# |    2|2019-07-01|  3600|  c101|mumbai|  2019-07-16|   360.0|    Lower|   Anand|    18000|
# |    3|2019-11-01|  6900|  c102|  pune|  2019-11-16|   690.0|   Higher|  Milind|    23990|
# +-----+----------+------+------+------+------------+--------+---------+--------+---------+

#custInvoices.printSchema()
#With default schema
# root
#  |-- invno: integer (nullable = true)
#  |-- invdate: string (nullable = true)
#  |-- invamt: integer (nullable = true)
#  |-- custid: string (nullable = true)
#  |-- city: string (nullable = true)

#With Custom Schema
# root
#  |-- invno: integer (nullable = true)
#  |-- invdate: date (nullable = true)
#  |-- invamt: integer (nullable = true)
#  |-- custid: string (nullable = true)
#  |-- city: string (nullable = true)