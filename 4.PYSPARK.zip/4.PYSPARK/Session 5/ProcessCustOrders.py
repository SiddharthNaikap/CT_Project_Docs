# import findspark
# findspark.init()
import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as fn

# spark-submit --master<url>
#              --deploy-mode client|cluster
#              abc.py

#spark-submit --num-executors 3 --executor-cores 7 --executor-memory 50GB
spark = SparkSession\
        .builder\
        .appName("custOrderApp")\
        .master("local[2]")\
        .getOrCreate()

custOrders = spark.read\
            .format("csv")\
            .option("header","true")\
            .option("inferSchema","true")\
            .load(sys.argv[1])
            # .load("./custOrder1.txt")

# print(custOrders)
# DataFrame[OrderNo: int, CustNo: string, City: string, OrderAmt: int]           

custOrdersGroup= custOrders.groupBy("City").agg(fn.sum("OrderAmt").alias("totalbiz"),fn.count("OrderNo").alias("#Orders"))
custOrdersGroup.show()

# default partitions = 200, setting it to 5
spark.conf.set("spark.sql.shuffle.partitions",5)
print("#Partitions : ",custOrdersGroup.rdd.getNumPartitions())

#writing into a file
custOrdersGroup.write\
                .format("json")\
                .mode("append")\
                .option("path","custOrderGroup")\
                .save()