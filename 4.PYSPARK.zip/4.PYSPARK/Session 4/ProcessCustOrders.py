import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as fn

# spark-submit --master<url>
#              --deploy-mode client|cluster
#              abc.py

spark = SparkSession\
        .builder\
        .appName("custOrderApp")\
        .master("local[2]")\
        .getOrCreate()

custOrders = spark.read\
            .format("csv")\
            .option("header","true")\
            .option("inferSchema","true")\
            .load(sys.argv[1])
            # .load("./custOrder1.txt")

# print(custOrders)
# DataFrame[OrderNo: int, CustNo: string, City: string, OrderAmt: int]           

custOrdersGroup= custOrders.groupBy("City").agg(fn.sum("OrderAmt").alias("totalbiz"),fn.count("OrderNo").alias("#Orders"))
custOrdersGroup.show()