import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as fn
from pyspark.sql.types import StructType,StructField,StringType,DateType,IntegerType

spark = SparkSession\
        .builder\
        .appName("streamingData")\
        .master("local[2]")\
        .getOrCreate()

custInvSchema = StructType([
    StructField("invno",IntegerType()),
    StructField("invdate",DateType()),
    StructField("invamt",IntegerType()),
    StructField("custid",StringType()),
    StructField("city",StringType())
])

custInvoices = spark.readStream\
            .format("csv")\
            .option("header","true")\
            .schema(custInvSchema)\
            .option("dateFormat","dd/MM/yyyy")\
            .load(sys.argv[1])
            # .load("./custOrder1.txt")


custOrdersGroup= custInvoices.groupBy("city").agg(fn.sum("invamt").alias("TotalAmt"),fn.count("invno").alias("TotalInv"))

# custInvoiceJoin.show()


invStream=custOrdersGroup.writeStream\
    .format("console")\
    .outputMode("complete")\
    .option("checkpointlocation","chkpoint")\
    .trigger(processingTime='5 seconds')\
    .start()

print("Waiting for invoices to be generated")
invStream.awaitTermination()

