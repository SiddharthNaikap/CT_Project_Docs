# from cgitb import reset
import findspark
findspark.init()
from pyspark import SparkConf,SparkContext
import re

# master = local host, with 2  executor cores
confObj = SparkConf().setMaster("local").setAppName("wordapp")
sc = SparkContext(conf=confObj)


def SplitWord(line):
    return re.compile(r'\W+',re.UNICODE).split(line.lower())

# return type is Resilient Distributed Dataset (RDD)
# 200 lines means 200 RDD instances returned
# lines = sc.textFile("file:///C:/Users/SiddharthaN/Desktop/Words.txt")

#Read multiple files and process, executed at master
lines = sc.textFile("file:///C:/Users/SiddharthaN/Desktop/*.txt")

words = lines.flatMap(SplitWord)
#words = lines.map(SplitWord)

# result = words.collect()
# for r in result:
#     print(r,"==>",type(r))

#When using flatMap()
# hi ==> <class 'str'>
# hello ==> <class 'str'>
# there ==> <class 'str'>
# go ==> <class 'str'>
# now ==> <class 'str'>
# who ==> <class 'str'>

#When using map()
# ['hi', 'hello', 'there'] ==> <class 'list'>
# ['go', 'now', 'who'] ==> <class 'list'>

#filter empty words if any
words = words.filter(lambda w:w !="")

wordsmap = words.map(lambda w :(w,1))

# res= wordsmap.collect()
# for r in res:
#     print(r)
# ('word', 1)
# ('count', 1)
# ('from', 1)
# ('wikipedia', 1)
# ('the', 1)

wordsunique =wordsmap.reduceByKey(lambda c1,c2:c1+c2)

# res= wordsunique.collect()
# for r in res:
#     print(r)
# ('word', 6)
# ('count', 3)
# ('from', 1)
# ('wikipedia', 1)
# ('the', 6)

#swapping key - value positions
wordsmap2 = wordsunique.map(lambda w:(w[1],w[0]))

# res= wordsmap2.collect()
# for r in res:
#     print(r)
# (6, 'word')
# (3, 'count')
# (1, 'from')
# (1, 'wikipedia')
# (6, 'the')
# (1, 'free')

#Sort in desending orde based on key
wordsfinal = wordsmap2.sortByKey(False)

# take,collect -- these actions are performed in Master Node
result = wordsfinal.take(10)

print("Most occuring top 10 words :")
for r in result:
    print(r[1],"Occurs",r[0],"times")
# of Occurs 7 times
# to Occurs 7 times
# word Occurs 6 times
# the Occurs 6 times
# and Occurs 6 times
# in Occurs 5 times
# is Occurs 4 times
# words Occurs 4 times
# a Occurs 4 times
# may Occurs 4 times