import { LightningElement } from 'lwc';

export default class PositionSkillMapping extends LightningElement {}