import sys
# import com.crealytics.spark.excel
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext 
from pyspark.sql import functions as fn
from pyspark.sql.types import StructType,StructField,StringType,DateType,IntegerType,FloatType

spark = SparkSession\
        .builder\
        .appName("Complications")\
        .master("local[2]")\
        .getOrCreate()
sql = SQLContext(spark)

DeathSchema = StructType([
    StructField("Facility ID",IntegerType()),
    StructField("Facility Name",StringType()),
    StructField("Address",StringType()),
    StructField("City",StringType()),
    StructField("State",StringType()),
    StructField("ZIP Code",IntegerType()),
    StructField("County Name",StringType()),
    StructField("Phone Number",IntegerType()),
    StructField("Measure ID",StringType()),
    StructField("Measure Name",StringType()),
    StructField("Compared to National",StringType()),
    StructField("Denominator",FloatType()),
    StructField("Score",FloatType()),
    StructField("Lower Estimate",FloatType()),
    StructField("Higher Estimate",FloatType()),
    StructField("Footnote",StringType()),
    StructField("Start Date",DateType()),
    StructField("End Date",DateType()),
    StructField("Flag",StringType())
])

Complications = spark.read\
            .format("csv")\
            .option("header","true")\
            .schema(DeathSchema)\
            .option("dateFormat","MM/dd/yyyy")\
            .load("./Complications_and_Deaths_Hospital.csv")			
# Complications.show()

Complications.createOrReplaceTempView("Data")

print("AVG of Denominator :")
sqlDF1 = spark.sql("SELECT AVG(`Denominator`) FROM Data WHERE `Denominator` IS NOT NULL")
# sqlDF1 = spark.sql("SELECT `Facility ID`,`Facility Name`,Denominator,`Measure ID` FROM Data WHERE `Facility ID` =10005 AND `Denominator` IS NOT NULL SORT BY Denominator DESC")
sqlDF1.show()

print("Facility with Denominator > Avg(denominator) and given County Name")
sqlDF = spark.sql("SELECT DISTINCT `Facility ID`,`Facility Name`,`County Name`,Denominator FROM Data  WHERE `County Name`='Coffee' and Denominator >(SELECT AVG(Denominator) FROM DATA WHERE `Denominator` IS NOT NULL)" )
sqlDF.show()


sqlQ=spark.sql("SELECT AVG(Denominator),State FROM Data WHERE `County Name`='York' AND Denominator IS NOT NULL GROUP BY State ")
sqlQ.show()

Complications.agg({'Denominator': 'count'}).show()

# query ='''
# insert into Data(`Facility ID`,`Facility Name`)
# values(1111111,'Sidd')
# '''
# sql2=spark.sql(query)
# sql2.show()

# UPDATE table SET
#     pay1 = CASE WHEN @columnname IN('name1') THEN pay1 * 100 ELSE pay1 END,